# Adjustments to Current Population Survey (CPS) weights to reflect CBO's 'Census Through 2020 + CBO Projection' of the Civilian Noninstitutionalized Population from 2000 to 2025

This data supplements CBO's January 2026 report The Demographic Outlook: 2026 to 2056.
https://www.cbo.gov/publication/61879

## Contents
-----------------------------------------------------------------------------------------------------
-- FILENAME --				        	-- DESCRIPTION --
-----------------------------------------------------------------------------------------------------
README.txt						This file
Census_Through_2020_Plus_CBO_Projection.csv	Adjusted CPS Weights (CSV Format)
Census_Through_2020_Plus_CBO_Projection.dta	Adjusted CPS Weights (DTA Format)
Example Python Code.py				Example code to calculate adjusted CPS weights using Python
Example Stata Code.py				Example code to calculate adjusted CPS weights using Stata

To open the files without being restricted to read-only access, save the zipped archive to a 
local file directory and extract the files to a new directory.

## General Notes ##
Column headings are in row 1; data start in row 2.

## How to use ##
Adjusted CPS weights can be used by the following steps:

1. Download monthly CPS data from the NBER website:
https://www.nber.org/research/data/current-population-survey-cps-basic-monthly-data

2. Create a 'year' and 'month' variable corresponding to the year and month of the CPS data that you would like to use.

2. Merge in the 'adj_factor_pwsswgt' variable from the 'Census_Through_2020_Plus_CBO_Projection' dataset 
   by the variables: 'year', 'month', 'prtage', 'pesex', 'ptdtrace', 'pehspnon'.

3. Multiply the CPS weight variable: 'pwsswgt' by the adjustment factor: 'adj_factor_pwsswgt'

4. Use the new weight variable in place of the CPS variable 'pwsswgt'.
