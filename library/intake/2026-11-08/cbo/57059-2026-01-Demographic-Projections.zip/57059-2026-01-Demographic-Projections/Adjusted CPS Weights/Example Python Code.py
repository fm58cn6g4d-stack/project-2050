import pandas as pd 

"""
This script demonstrates how to adjust monthly CPS weights to reflect the Congressional 
Budget Office's projected 'Census Through 2020 Plus CBO Projection' of the civilian 
noninstitutionalized population.

The process involves:
1. Loading monthly CPS data from NBER 
2. Loading CBO population projection adjustment factors (available from April 2020 onward)
3. Merging the adjustment factors with CPS data based on demographic characteristics
4. Calculating adjusted weights by multiplying original CPS weights with adjustment factors

Key variables:
- pwsswgt: Original monthly CPS weight (has implied decimals, multiply by 10,000 for full counts)
- adj_factor_pwsswgt: CBO adjustment factor for population projections
- adj_pwsswgt: Final adjusted CPS weight

Data sources:
- Monthly CPS data: https://data.nber.org/cps-basic3/csv/
- CBO adjustment factors: Census_Through_2020_Plus_CBO_Projection.csv

Merge keys: year, month, prtage (age), pesex (sex), ptdtrace (race), pehspnon (Hispanic origin)
"""

# Set project directory
project_directory = ""

# Load monthly CPS data 
# (NOTE: CBO's CPS weight adjustment factors are available from April 2020 onward)
cps_data = pd.read_csv(project_directory + "cpsb202101.csv")

# Define the year and month for the CPS extract (used for merging CBO weight adjustment factors)
cps_data['year'] = 2021
cps_data['month'] = 1

# Set index for merging in weights later
cps_data.set_index(['year', 'month', 'prtage', 'pesex', 'ptdtrace', 'pehspnon'], inplace=True)

# Load CBO weight adjustment factors
cbo_adjustment_factors = pd.read_csv(project_directory + "Census_Through_2020_Plus_CBO_Projection.csv")

# Set index values for merging into CPS extract
cbo_adjustment_factors.set_index(['year', 'month', 'prtage', 'pesex', 'ptdtrace', 'pehspnon'], inplace=True)

# Merge CBO adjustment factors into CPS data
cps_data = cps_data.merge(cbo_adjustment_factors, how='left', left_index=True, right_index=True)

# Calculate adjusted CPS weights
cps_data['adj_pwsswgt'] = cps_data['pwsswgt'] * cps_data['adj_factor_pwsswgt']
