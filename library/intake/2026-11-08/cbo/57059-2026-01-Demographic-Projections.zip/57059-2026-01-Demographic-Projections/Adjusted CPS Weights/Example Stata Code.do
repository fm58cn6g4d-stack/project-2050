/*
This script demonstrates how to adjust monthly CPS weights to reflect the Congressional 
Budget Office's projected 'Census Through 2020 Plus CBO Projection' of the civilian 
noninstitutionalized population.

The process involves:
1. Loading monthly CPS data from NBER 
2. Loading CBO population projection adjustment factors (available from April 2020 onward)
3. Merging the adjustment factors with CPS data based on demographic characteristics
4. Calculating adjusted weights by multiplying original CPS weights with adjustment factors

Key variables:
- pwsswgt: Original monthly CPS weight (has implied decimals, multiply by 10,000 for full counts)
- adj_factor_pwsswgt: CBO adjustment factor for population projections
- adj_pwsswgt: Final adjusted CPS weight

Data sources:
- Monthly CPS data: https://data.nber.org/cps-basic3/csv/
- CBO adjustment factors: Census_Through_2020_Plus_CBO_Projection.csv

Merge keys: year, month, prtage (age), pesex (sex), ptdtrace (race), pehspnon (Hispanic origin)
*/

clear all

* Set project directory
cd ""

* Load CBO weight adjustment factors
import delimited using "Census_Through_2020_Plus_CBO_Projection.csv"
save "Census_Through_2020_Plus_CBO_Projection.dta", replace

* Load monthly CPS Data 
* (NOTE: CBO's CPS weight adjustment factors are available from April 2020 onward)
clear
import delimited using "cpsb202101.csv"

* Define the year and month for the CPS extract 
* (used for merging CBO weight adjustment factors)
gen year = 2021
gen month = 1

* Merge CBO adjustment factors into CPS data
merge m:1 year month prtage pesex ptdtrace pehspnon using "Census_Through_2020_Plus_CBO_Projection.dta"

* Calculate adjusted CPS weights
gen adj_pwsswgt = pwsswgt * adj_factor_pwsswgt
