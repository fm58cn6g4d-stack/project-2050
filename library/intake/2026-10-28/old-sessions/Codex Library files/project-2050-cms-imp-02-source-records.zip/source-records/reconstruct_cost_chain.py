"""Reconstruct published contract prices; no Project 2050 cost is estimated."""
from decimal import Decimal as D
import json

phase_v = {
    'governance': '8015.00', 'advisory_charter': '8015.00',
    'lead_assessment': '131955.50', 'lead_project_list': '38425.50',
    'lead_facilitation': '339840.56', 'lead_post_report': '23605.50',
    'support_assessment': '107465.00', 'support_project_list': '30645.00',
    'support_facilitation': '122160.56', 'support_post_report': '16505.00',
    'training': '154000.38',
}
removed = ['lead_facilitation', 'lead_post_report', 'support_facilitation',
           'support_post_report', 'training']
replacements = {'interim_training': '50000.00', 'final_training': '104000.80',
                'on_job_roadmap': '302111.60', 'transition_memo': '40110.50'}
old_increment = sum(map(D, phase_v.values()))
removed_total = sum(D(phase_v[k]) for k in removed)
replacement_total = sum(map(D, replacements.values()))
new_increment = old_increment - removed_total + replacement_total
prior_base = D('2183174.00')
prior_schedule = D('3163807.00')
new_schedule = D('3003917.90')
assert old_increment == prior_schedule - prior_base == D('980633.00')
assert removed_total == D('656112.00')
assert replacement_total == D('496222.90')
assert new_increment == D('820743.90')
assert prior_base + new_increment == new_schedule
assert new_schedule - prior_schedule == D('-159889.10')
assert D('167972688') + D('42458648') + D('13937232') == D('224368568')
assert D('224368568') + D('55000000') + D('5000000') == D('284368568')
print(json.dumps({
    'currency_basis': 'Nominal contract prices; no inflation conversion',
    'sources': {'added_rows':'R03 pp.15-16', 'replacements':'R05 p.21',
                'one_control':'R01 pp.225-227'},
    'phase_v_amendment_4_rows': phase_v,
    'removed_row_ids': removed,
    'amendment_6_replacements': replacements,
    'old_increment': str(old_increment), 'removed_total': str(removed_total),
    'replacement_total': str(replacement_total),
    'revised_phase_v_schedule': str(new_increment),
    'revised_contract_payment_table': str(new_schedule),
    'payment_table_delta': str(new_schedule-prior_schedule),
    'section_3_ceiling_reconciliation': 'Unresolved; no cash release inferred',
    'hlt_1_incremental_cost': None, 'federal_share': None, 'state_share': None,
    'fy2029_cash': None, 'spare_capacity': None,
    'policy_or_model_inputs_changed': False,
}, indent=2))
