# Public source records

The PDFs are unchanged copies downloaded from public Oregon state sources on October 23, 2026. `source-manifest.json` records the actual URLs, sizes and SHA-256 hashes. The two procurement HTML pages and two master-record HTML pages preserve the attachment indexes available during the search.

`reconstruct_cost_chain.py` uses Python's standard library and exact decimal arithmetic. Run `python3 reconstruct_cost_chain.py` to reproduce the historical/revised PCG price checks and ONE ceiling reconciliation. Its saved result is `calculation-record.json`. These calculations do not establish actual spending, matching eligibility, released funds or the cost of HLT-1.

Selected source locations and limits are in the accompanying follow-up report. The downloaded ONE support attachment is a signed 2023 base contract; later current terms require the amendment register. PCG amendment 6 has a September 2026 signature and redlines that plain text extraction does not resolve; use the original PDF's operative text. The source pack includes no APD or funded individual Deloitte Service Order because neither was located. It includes no generated PDF page screenshots.
